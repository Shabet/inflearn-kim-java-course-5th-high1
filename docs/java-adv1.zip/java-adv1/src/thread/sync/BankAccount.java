package thread.sync;

public interface BankAccount {

    boolean withdraw(int amount);

    int getBalance();
}
