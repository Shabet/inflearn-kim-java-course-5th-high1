package thread.cas.increment;

public interface IncrementInteger {
    void increment();

    int get();
}
