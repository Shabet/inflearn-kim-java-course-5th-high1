package thread.collection.simple.list;

public interface SimpleList {
    int size();

    void add(Object e);

    Object get(int index);
}
