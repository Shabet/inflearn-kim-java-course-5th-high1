package util;

import static util.MyLogger.*;

public class MyLoggerMain {

    public static void main(String[] args) {
        log("hello thread");
        log(123);
    }
}
